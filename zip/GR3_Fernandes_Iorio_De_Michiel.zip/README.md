Etudiants: 
  Bruno Fernandes Iorio 
  Gildas De Michiel
  
  Pour exécuter le programme, il suffit de rentrer la commande suivante dans le terminal :
    python main.py

  Le dossier example contient les matrices des question (c) et (d).
    instances.txt contient les entrées de la question (c), tandis que results.txt contient les sorties de la question (c).
    instances_obstacles.txt contient les entrées de la question (d), tandis que results_obstacles.txt contient les sorties de la question (d).
